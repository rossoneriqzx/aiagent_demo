# 智能投资顾问 Agent 系统

一个基于 RAG（检索增强生成）和工具调用的工业级智能投资顾问 Agent，支持多模型、个性化检索和远程工具集成。

## 📋 目录

- [功能特性](#功能特性)
- [技术栈](#技术栈)
- [项目结构](#项目结构)
- [快速开始](#快速开始)
- [配置说明](#配置说明)
- [使用示例](#使用示例)
- [开发指南](#开发指南)
- [常见问题](#常见问题)

## ✨ 功能特性

### 核心能力

- 🤖 **多模型支持**：支持 OpenAI、Qwen（通义千问）、DeepSeek、Azure 等多种 LLM 提供商
- 📚 **RAG 知识库**：基于 ChromaDB 的向量检索，支持通用知识库和用户专属知识库
- 👤 **个性化服务**：用户画像分析、兴趣识别、专业水平评估
- 🔧 **工具调用**：支持本地 Python 工具和远程 MCP（Model Context Protocol）工具
- 🔄 **流式输出**：支持实时流式响应
- ⚙️ **灵活配置**：YAML 配置文件 + 环境变量覆盖

### 高级特性

- 用户交互学习：记录用户反馈，持续优化检索结果
- 多轮工具调用：支持最多 3 轮工具调用循环
- 异常处理与重试：完善的错误处理和自动重试机制
- 监控与日志：内置监控指标和结构化日志

## 🛠 技术栈

- **Python 3.8+**
- **LLM 客户端**：OpenAI SDK（兼容国内模型）
- **向量数据库**：ChromaDB
- **Web 框架**：FastAPI（Web API + MCP 服务器）
- **配置管理**：Pydantic + PyYAML
- **HTTP 客户端**：httpx

## 📁 项目结构

```
mvp/
├── config.yaml              # 主配置文件
├── requirements.txt         # Python 依赖
├── README.md               # 项目文档
└── src/
    ├── agent.py            # Agent 核心逻辑
    ├── config.py           # 配置管理模块
    ├── llm_client.py       # LLM 客户端
    ├── rag.py              # RAG 检索增强生成
    ├── mcp_client.py       # MCP 工具客户端
    ├── fake_mcp_server.py  # MCP 服务器示例
    ├── rag_demo_setup.py   # RAG 知识库初始化脚本
    ├── web.py              # Web 应用后端
    ├── start_web.sh        # Web 启动脚本
    ├── static/             # 前端静态文件
    │   ├── index.html      # 前端页面
    │   ├── style.css       # 样式文件
    │   └── app.js          # 前端逻辑
    └── knowledge_base_data/ # 向量数据库存储目录
        ├── chroma.sqlite3  # 通用知识库
        └── users/          # 用户专属知识库
```

## 🚀 快速开始

### 1. 环境准备

确保已安装 Python 3.8 或更高版本：

```bash
python --version
```

### 2. 安装依赖

```bash
cd /Users/qiuzixiao/Desktop/mvp
pip install -r requirements.txt
```

### 3. 配置 API Key

设置环境变量（根据你使用的模型提供商选择）：

```bash
# 使用 Qwen（通义千问）
export QWEN_API_KEY="your-qwen-api-key"

# 或使用 DeepSeek
export DEEPSEEK_API_KEY="your-deepseek-api-key"

# 或使用 OpenAI
export OPENAI_API_KEY="your-openai-api-key"
```

### 4. 初始化知识库（可选）

```bash
cd src
python rag_demo_setup.py
```

这将创建示例文档并索引到知识库中。

### 5. 启动 MCP 服务器（如需要工具调用）

在另一个终端窗口：

```bash
cd src
uvicorn fake_mcp_server:app --host 127.0.0.1 --port 8000
```

### 6. 运行 Agent

#### 方式一：命令行界面（CLI）

```bash
cd src
python agent.py
```

启动后，你可以输入问题与 Agent 交互，输入 `/exit` 退出。

#### 方式二：Web 界面（推荐）

```bash
cd src
python web.py
# 或使用启动脚本
./start_web.sh
```

然后在浏览器中访问：**http://localhost:8080**

Web 界面特性：
- 🎨 现代化的聊天界面
- 🔄 实时流式响应
- ⚙️ 可配置 RAG 和工具调用
- 📊 显示 Token 使用情况
- 📱 响应式设计，支持移动端

## ⚙️ 配置说明

### 配置文件结构

主配置文件 `config.yaml` 包含以下主要部分：

```yaml
# 基础配置
name: "investment_agent_demo"
version: "1.0.0"
environment: "development"

# 模型配置
model:
  provider: "qwen"  # openai, qwen, deepseek, azure, custom
  model_name: "qwen-turbo"
  base_url: "https://dashscope.aliyuncs.com/compatible-mode/v1"
  temperature: 0.3
  max_tokens: 1024
  timeout: 60

# 系统提示词
system_prompt: >
  你是一个专业的投资顾问助手，回答要简洁、专业，必要时解释推理过程。

# 知识库配置
knowledge_base:
  enabled: true
  storage_type: "chromadb"
  storage_path: "./knowledge_base_data"
  collection_name: "test_kb"
  embedding:
    provider: "qwen"
    model_name: "text-embedding-v1"
    base_url: "https://dashscope.aliyuncs.com/compatible-mode/v1"
    timeout: 120
  top_k: 5
  similarity_threshold: 0.6

# MCP 工具配置
use_mcp: true
mcp_servers:
  - label: "demo"
    url: "http://127.0.0.1:8000"
    enabled: true
    timeout: 30
    retry_attempts: 3
```

### 环境变量覆盖

支持通过环境变量覆盖配置：

```bash
export AGENT_NAME="my_agent"
export AGENT_ENVIRONMENT="production"
export AGENT_MODEL_NAME="qwen-plus"
```

### 支持的模型提供商

- **OpenAI**：`provider: "openai"`
- **Qwen（通义千问）**：`provider: "qwen"`
- **DeepSeek**：`provider: "deepseek"`
- **Azure OpenAI**：`provider: "azure"`
- **自定义**：`provider: "custom"`

## 🌐 Web 界面使用

### 启动 Web 服务

```bash
cd src
python web.py
```

或使用启动脚本：

```bash
cd src
./start_web.sh
```

### 访问界面

在浏览器中打开：**http://localhost:8080**

### Web 界面功能

1. **聊天交互**
   - 输入问题并发送
   - 支持流式输出（实时显示生成内容）
   - 显示工具调用和 Token 使用情况

2. **配置选项**
   - 启用/禁用 RAG 知识库检索
   - 启用/禁用工具调用
   - 启用/禁用流式输出

3. **API 端点**

   - `GET /` - Web 界面首页
   - `GET /api/health` - 健康检查
   - `GET /api/config` - 获取配置信息
   - `POST /api/chat` - 非流式聊天
   - `POST /api/chat/stream` - 流式聊天（Server-Sent Events）

### API 使用示例

#### 非流式聊天

```bash
curl -X POST http://localhost:8080/api/chat \
  -H "Content-Type: application/json" \
  -d '{
    "message": "什么是分散投资？",
    "user_id": "user_001",
    "enable_rag": true,
    "enable_tools": true
  }'
```

#### 流式聊天

```bash
curl -X POST http://localhost:8080/api/chat/stream \
  -H "Content-Type: application/json" \
  -d '{
    "message": "请介绍一下投资组合理论",
    "user_id": "user_001",
    "enable_rag": true
  }'
```

## 💡 使用示例

### 基础对话

```python
import asyncio
from src.agent import create_agent

async def main():
    agent = create_agent()
    
    response = await agent.chat(
        user_input="什么是分散投资？",
        user_id="user_001",
        enable_rag=True,
        enable_tools=False
    )
    
    print(response.content)

asyncio.run(main())
```

### 启用工具调用

```python
async def main():
    # 注册自定义工具
    async def get_stock_price(symbol: str) -> dict:
        """获取股票价格"""
        # 实现你的逻辑
        return {"symbol": symbol, "price": 100.0}
    
    tools = {
        "get_stock_price": get_stock_price
    }
    
    agent = create_agent(extra_tools=tools)
    
    response = await agent.chat(
        user_input="帮我查一下 AAPL 的股价",
        user_id="user_001",
        enable_rag=True,
        enable_tools=True  # 启用工具调用
    )
    
    print(response.content)

asyncio.run(main())
```

### 流式输出

```python
async def main():
    agent = create_agent()
    
    async for chunk in agent.stream_chat(
        user_input="请介绍一下投资组合理论",
        user_id="user_001",
        enable_rag=True
    ):
        print(chunk.content, end="", flush=True)
    print()  # 换行

asyncio.run(main())
```

### 索引文档到知识库

```python
from src.config import ConfigManager
from src.rag import create_enhanced_rag_pipeline

async def main():
    cfg_manager = ConfigManager()
    cfg = cfg_manager.get_config()
    
    rag = create_enhanced_rag_pipeline(cfg)
    
    texts = [
        "分散投资是降低投资风险的重要策略。",
        "资产配置需要考虑风险承受能力和投资目标。"
    ]
    
    metadatas = [
        {"source": "investment_guide", "topic": "risk_management"},
        {"source": "investment_guide", "topic": "asset_allocation"}
    ]
    
    rag.index_documents(
        texts=texts,
        metadatas=metadatas,
        user_id=None  # None 表示索引到通用知识库
    )

asyncio.run(main())
```

## 🔧 开发指南

### 添加自定义工具

1. 定义异步工具函数：

```python
async def my_custom_tool(param1: str, param2: int) -> dict:
    """
    工具描述（会被用于生成 schema）
    
    Args:
        param1: 参数1说明
        param2: 参数2说明
    
    Returns:
        工具执行结果
    """
    # 实现工具逻辑
    return {"result": "success"}
```

2. 注册到 Agent：

```python
tools = {
    "my_custom_tool": my_custom_tool
}
agent = create_agent(extra_tools=tools)
```

### 创建 MCP 服务器

参考 `fake_mcp_server.py`，实现两个接口：

1. **GET /tools**：返回工具列表
2. **POST /call**：执行工具调用

```python
from fastapi import FastAPI
from pydantic import BaseModel

app = FastAPI()

@app.get("/tools")
def list_tools():
    return [
        {
            "name": "my_tool",
            "description": "工具描述",
            "parameters": {
                "type": "object",
                "properties": {
                    "param": {"type": "string"}
                },
                "required": ["param"]
            }
        }
    ]

@app.post("/call")
def call_tool(body: dict):
    tool_name = body["tool"]
    args = body["arguments"]
    # 执行工具逻辑
    return {"result": "执行结果"}
```

### 扩展 Embedding 提供商

在 `rag.py` 的 `EnhancedEmbeddingClient` 中添加新的提供商支持。

## ❓ 常见问题

### Q: 如何切换不同的 LLM 模型？

A: 修改 `config.yaml` 中的 `model.provider` 和 `model.model_name`，并设置对应的 API Key 环境变量。

### Q: 知识库检索没有结果？

A: 检查以下几点：
1. `knowledge_base.enabled` 是否为 `true`
2. 是否已运行 `rag_demo_setup.py` 初始化知识库
3. `similarity_threshold` 是否设置过高

### Q: MCP 工具调用失败？

A: 确认：
1. MCP 服务器是否在运行（`uvicorn fake_mcp_server:app --host 127.0.0.1 --port 8000`）
2. `config.yaml` 中的 `mcp_servers` 配置是否正确
3. 网络连接是否正常

### Q: 如何查看详细的日志？

A: 设置日志级别：

```python
import logging
logging.basicConfig(level=logging.DEBUG)
```

### Q: 支持哪些向量数据库？

A: 目前支持 ChromaDB，未来可扩展支持 Pinecone、Weaviate 等。

## 📝 许可证

本项目为示例项目，可根据需要修改和扩展。

## 🤝 贡献

欢迎提交 Issue 和 Pull Request！

---

**注意**：使用前请确保已正确配置 API Key 和网络环境。对于国内用户，建议使用 Qwen 或 DeepSeek 等国内模型提供商以获得更好的访问体验。

