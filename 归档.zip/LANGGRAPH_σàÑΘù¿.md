# LangGraph 快速入门指南

## 🚀 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

这会安装 `langgraph` 和 `langchain-core`。

### 2. 运行示例代码

```bash
python src/langgraph_demo.py
```

这个脚本包含三个演示：
- **演示 1**：最简单的聊天图（理解基础概念）
- **演示 2**：RAG 工作流（基于你的项目结构）
- **演示 3**：带工具调用的 Agent（展示条件路由）

### 3. 阅读教程

打开 `src/langgraph_tutorial.md` 查看详细教程，包括：
- 核心概念解释
- 传统方式 vs LangGraph 对比
- 实战示例
- 最佳实践

---

## 📁 文件说明

- **`src/langgraph_demo.py`** - 可运行的示例代码
- **`src/langgraph_tutorial.md`** - 详细教程文档
- **`requirements.txt`** - 已更新，包含 langgraph 依赖

---

## 🎯 核心概念速记

### State（状态）
```python
class ChatState(TypedDict):
    messages: Annotated[List[LLMMessage], add_messages]
    user_input: str
```

### Node（节点）
```python
def my_node(state: ChatState) -> ChatState:
    # 处理逻辑
    return {"user_input": "更新后的值"}
```

### Graph（图）
```python
builder = StateGraph(ChatState)
builder.add_node("my_node", my_node)
builder.set_entry_point("my_node")
builder.add_edge("my_node", END)
graph = builder.compile()
```

### 运行图
```python
result = graph.invoke({"user_input": "你好"})
```

---

## 💡 下一步建议

1. **运行示例**：先跑通 `langgraph_demo.py`，理解基本流程
2. **阅读教程**：看 `langgraph_tutorial.md` 了解详细概念
3. **尝试改造**：把你现有的 `agent.py` 中的某个方法改成 LangGraph 版本
4. **探索高级特性**：
   - 检查点（Checkpointer）用于会话恢复
   - 条件边（Conditional Edges）用于动态路由
   - 流式输出（Streaming）

---

## ❓ 常见问题

**Q: 必须用 LangGraph 吗？**  
A: 不是必须的。如果你的流程很简单，传统方式也可以。但如果你需要：
- 复杂的多步骤流程
- 可视化工作流
- 暂停/恢复功能
- 多 Agent 协作

那么 LangGraph 会很有帮助。

**Q: 会影响现有代码吗？**  
A: 不会。LangGraph 是**增量式**的，你可以：
- 保留现有的 `agent.py`、`rag.py` 等
- 只把**新功能**用 LangGraph 实现
- 逐步迁移

**Q: 性能如何？**  
A: LangGraph 本身开销很小（主要是图遍历）。性能瓶颈通常在 LLM 调用，和传统方式一样。

---

## 📚 更多资源

- **官方文档**：https://langgraph.readthedocs.io
- **GitHub**：https://github.com/langchain-ai/langgraph
- **示例集合**：https://github.com/langchain-ai/langgraph/tree/main/examples

---

祝你学习愉快！🎉

