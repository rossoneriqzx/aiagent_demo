"""
agent.py - Industrial-grade Agent Core

依赖:
- config.py: AgentConfig / ConfigManager / ModelConfig / ModelProvider
- rag.py: create_enhanced_rag_pipeline / EnhancedRAGPipeline
- llm_client.py: create_llm_client / LLMMessage / LLMResponse

特性:
- 支持可选 RAG（知识库检索）
- 支持工具调用（function calling 风格）
- 与国内 OpenAI-compatible 模型完全兼容
- 提供同步的 Agent 封装 + 异步 CLI Demo
"""

from __future__ import annotations

import asyncio
import inspect
import json
import logging
from typing import Any, Awaitable, Callable, Dict, List, Optional

from config import ConfigManager, AgentConfig
from rag import create_enhanced_rag_pipeline, EnhancedRAGPipeline
from llm_client import (
    create_llm_client,
    LLMMessage,
    LLMResponse,
    StreamChunk,
)
from mcp_client import MCPClient

logger = logging.getLogger(__name__)


# 工具函数类型: name -> async callable(**kwargs) -> Any
ToolCallable = Callable[..., Awaitable[Any]]


class Agent:
    """
    核心 Agent：
    - 负责把 Config / LLM / RAG / Tools 串起来
    - 对外提供 async `chat()` / `stream_chat()` 接口
    """

    def __init__(
        self,
        cfg: AgentConfig,
        extra_tools: Optional[Dict[str, ToolCallable]] = None,
    ) -> None:
        self.cfg = cfg

        # LLM 客户端（基于 ModelConfig）
        self.llm = create_llm_client(cfg.model)

        # RAG：只有在 config 中 enabled 才启用
        self.rag: Optional[EnhancedRAGPipeline] = None
        if cfg.knowledge_base.enabled:
            # 自动补全 API Key：如果 embedding 没配 key，且 provider 和 llm 一样，就复用 llm 的 key
            kb_cfg = cfg.knowledge_base
            if not kb_cfg.embedding.api_key:
                if kb_cfg.embedding.provider == cfg.model.provider and cfg.model.api_key:
                    kb_cfg.embedding.api_key = cfg.model.api_key
                    logger.info(f"复用 LLM API Key 给 RAG Embedding ({kb_cfg.embedding.provider})")

            try:
                self.rag = create_enhanced_rag_pipeline(cfg)
                logger.info("RAG pipeline initialized.")
            except Exception as e:
                logger.error("Failed to initialize RAG pipeline: %s", e)
                self.rag = None

        # 工具系统（可选）
        # 1）本地 Python 工具（通过 extra_tools 传入）
        self.tools: Dict[str, ToolCallable] = extra_tools or {}

        # 2）MCP 远程工具（如果在配置中启用）
        self.mcp_client: Optional[MCPClient] = None
        self._mcp_tool_names: List[str] = []
        if cfg.use_mcp and cfg.mcp_servers:
            try:
                logger.info(f"正在初始化 MCP 客户端，服务器数量: {len(cfg.mcp_servers)}")
                self.mcp_client = MCPClient(cfg.mcp_servers)
                mcp_tools = self.mcp_client.build_tool_wrappers()
                if mcp_tools:
                    self.tools.update(mcp_tools)
                    self._mcp_tool_names = list(mcp_tools.keys())
                    logger.info(
                        "✅ MCP 集成已启用，共注册 %d 个远程工具：%s",
                        len(mcp_tools),
                        self._mcp_tool_names,
                    )
                else:
                    logger.warning("⚠️ MCP 客户端初始化成功，但未发现任何工具。请检查 MCP 服务器是否正常运行。")
            except Exception as e:
                logger.error("❌ 初始化 MCPClient 失败，将忽略 MCP 工具: %s", e, exc_info=True)

        # 控制工具调用循环
        self.max_tool_iterations: int = 3
        self.user_histories: Dict[str, List[LLMMessage]] = {}
        # 历史记录窗口大小（保留最近 N 轮对话）
        self.history_window: int = getattr(cfg, 'memory_window', 10) if hasattr(cfg, 'memory_window') else 10
        # 对话总结配置
        self.summarize_enabled: bool = getattr(cfg, 'memory_summarize', True) if hasattr(cfg, 'memory_summarize') else True
        self.summarize_threshold: int = getattr(cfg, 'memory_summarize_threshold', 8) if hasattr(cfg, 'memory_summarize_threshold') else 8
        # 存储每个用户的总结信息
        self.user_summaries: Dict[str, str] = {}
        

    # ------------------------------------------------------------------
    # 对外核心接口
    # ------------------------------------------------------------------

    async def chat(
        self,
        user_input: str,
        user_id: str = "web_user",  # 改为 web_user，避免匿名用户不保存历史
        enable_rag: bool = True,
        enable_tools: bool = True,
    ) -> LLMResponse:
        """
        单轮高层封装：
        - 可选 RAG 检索
        - 可选工具调用（function calling 循环）
        - 支持对话历史（多轮上下文）
        - 返回最终的 LLMResponse
        """
        # 1. 构造初始 messages（含历史记录 + RAG 上下文）
        messages = await self._build_initial_messages(
            user_input=user_input,
            user_id=user_id,
            enable_rag=enable_rag,
        )

        # 2. 根据配置决定是否启用工具，并构造 tools schema
        tools_schema = None
        if enable_tools and self.cfg.tools_enabled and self.tools:
            tools_schema = self._build_tool_schemas()

        # 3. 第一次 LLM 调用
        response = await self.llm.chat(
            messages,
            tools=tools_schema,
            tool_choice="auto" if tools_schema else "none",
        )

        # 4. 若开启工具调用，则执行工具循环（最多 N 轮）
        if tools_schema and response.tool_calls:
            response = await self._tool_call_loop(base_messages=messages, initial_response=response, tools_schema=tools_schema)

        # 5. 保存对话历史（用于多轮对话上下文）
        self._save_conversation_history(user_id, user_input, response)

        return response

    async def stream_chat(
        self,
        user_input: str,
        user_id: str = "web_user",  # 改为 web_user，避免匿名用户不保存历史
        enable_rag: bool = True,
        enable_tools: bool = False,
    ):
        """
        流式版本（增强版）：
        - 支持工具调用（混合模式）：
          1. 先用非流式尝试获取工具调用
          2. 如果有工具调用，执行循环
          3. 最后一轮生成回答时，使用流式输出
        """
        # 1. 构造初始 messages
        messages = await self._build_initial_messages(
            user_input=user_input,
            user_id=user_id,
            enable_rag=enable_rag,
        )

        # 2. 准备工具 schema
        tools_schema = None
        if enable_tools and self.cfg.tools_enabled and self.tools:
            tools_schema = self._build_tool_schemas()

        # 3. 如果启用了工具，先进行预判断（非流式），处理潜在的工具调用
        if tools_schema:
            # 循环处理工具调用，直到模型不再调用工具或达到上限
            for iteration in range(self.max_tool_iterations):
                # 注意：这里我们用非流式调用来探测工具
                # 因为流式解析工具调用比较复杂，这里采用"思考-执行-再思考"的策略
                # 最后一轮才流式输出
                
                # 这一步我们其实无法预知模型是否会调用工具，所以我们必须先由模型决定
                # 但为了支持"最后一步流式"，我们需要一种机制
                
                # 简化策略：我们先发起一个非流式请求
                response = await self.llm.chat(
                    messages,
                    tools=tools_schema,
                    tool_choice="auto",
                )
                
                # 如果模型决定不调用工具，或者没有更多工具要调用
                if not response.tool_calls:
                    # 这里的 response.content 是完整的回答
                    # 但用户想要流式... 
                    # 补救：模拟一个流式输出
                    from llm_client import StreamChunk
                    # 逐字符或逐词输出以模拟流式效果
                    content = response.content
                    for i, char in enumerate(content):
                        yield StreamChunk(content=char, is_final=False)
                    yield StreamChunk(content="", is_final=True, usage=response.usage)
                    # 保存对话历史
                    self._save_conversation_history(user_id, user_input, response)
                    return

                # 如果有工具调用 -> 执行工具
                logger.info(f"流式预处理：检测到 {len(response.tool_calls)} 个工具调用")
                
                # 把 assistant 的思考过程（tool_calls）加入历史
                messages.append(
                    LLMMessage(
                        role="assistant",
                        content=response.content,
                        tool_calls=response.tool_calls,
                    )
                )
                
                # 执行工具
                tool_messages = await self._execute_tool_calls(response.tool_calls)
                if tool_messages:
                    messages.extend(tool_messages)
                
                # 继续下一轮循环...
                # 如果这是最后一轮允许的迭代，或者我们想在下一轮直接流式输出？
                # 我们继续循环，直到模型不再调用工具。
            
            # 循环结束（或达到上限），此时 messages 里已经包含了所有的工具执行结果
            # 下面发起最终的流式请求
            
        # 4. 最终流式输出（无论之前有没有工具调用）
        full_content = ""
        final_chunk = None
        usage_info = {}
        chunk_count = 0
        
        logger.info(f"🔄 开始流式输出（user_id={user_id}，enable_tools={enable_tools}）")
        
        try:
            async for chunk in self.llm.stream_chat(messages, tools=tools_schema):
                chunk_count += 1
                if chunk.content:
                    full_content += chunk.content
                if chunk.is_final:
                    final_chunk = chunk
                    logger.debug(f"收到 final chunk（user_id={user_id}，usage={chunk.usage}）")
                    if chunk.usage:
                        usage_info = chunk.usage
                yield chunk
        except Exception as e:
            logger.error(f"流式输出异常（user_id={user_id}）: {e}", exc_info=True)
            raise
        finally:
            # 5. 保存对话历史（流式模式）- 无论是否正常结束都要保存
            logger.info(f"🔄 流式输出结束（user_id={user_id}，chunk_count={chunk_count}，content_length={len(full_content)}，has_final_chunk={final_chunk is not None}）")
            
            # 确保即使流式输出异常，也能保存已收集的内容
            # 修改条件：只要有内容就保存，即使没有 final_chunk
            if full_content.strip():  # 只要有非空内容就保存
                from llm_client import LLMResponse
                final_response = LLMResponse(
                    content=full_content,
                    model="",  # 流式模式下可能没有 model 信息
                    usage=usage_info if usage_info else (final_chunk.usage if final_chunk and final_chunk.usage else {}),
                )
                logger.info(f"💾 准备保存流式对话历史（user_id={user_id}，内容长度={len(full_content)}）")
                self._save_conversation_history(user_id, user_input, final_response)
                logger.info(f"✅ 流式模式：已保存对话历史（user_id={user_id}，内容长度={len(full_content)}）")
            else:
                logger.warning(f"⚠️ 流式模式：未收集到内容，跳过历史记录保存（user_id={user_id}，full_content='{full_content[:50]}...'，chunk_count={chunk_count}）")
    
    # ------------------------------------------------------------------
    # 内部：tools schema 构造（给 LLM 用）
    # ------------------------------------------------------------------
    def _build_tool_schemas(self) -> List[Dict[str, Any]]:
        """
        汇总本地工具 + MCP 远程工具的 schema，转换成 OpenAI tools 规范。
        """
        schemas: List[Dict[str, Any]] = []

        # 1）本地工具
        schemas.extend(self._build_local_tool_schemas())

        # 2）MCP 远程工具
        if getattr(self, "mcp_client", None) is not None:
            try:
                mcp_schemas = self.mcp_client.build_tool_schemas()
                schemas.extend(mcp_schemas)
            except Exception as e:
                logger.error("构造 MCP 工具 schema 失败: %s", e)

        return schemas

    def _build_local_tool_schemas(self) -> List[Dict[str, Any]]:
        """
        根据已注册的本地 Python 工具自动生成 tools schema。

        - 会使用函数签名做一个简单的 JSON Schema 推断
        - 如果你希望精细控制，可以之后改成手写 schema
        """
        import inspect

        schemas: List[Dict[str, Any]] = []

        # 如果已经注册了 MCP 工具，我们只对非 MCP 的本地工具生成 schema
        mcp_tool_names = set(getattr(self, "_mcp_tool_names", []) or [])

        for name, fn in self.tools.items():
            # MCP 工具已经由 mcp_client 提供 schema，这里跳过
            if name in mcp_tool_names:
                continue

            try:
                sig = inspect.signature(fn)
                properties: Dict[str, Any] = {}
                required: List[str] = []

                for param_name, param in sig.parameters.items():
                    # 跳过 self 等
                    if param_name == "self":
                        continue

                    # 根据类型做个粗略映射
                    json_type = "string"
                    if param.annotation in (int, float):
                        json_type = "number"
                    elif param.annotation is bool:
                        json_type = "boolean"

                    properties[param_name] = {
                        "type": json_type,
                        "description": f"Parameter '{param_name}' for tool '{name}'",
                    }
                    if param.default is inspect._empty:
                        required.append(param_name)

                schema = {
                    "type": "function",
                    "function": {
                        "name": name,
                        "description": (fn.__doc__ or "").strip() or f"Tool function '{name}'",
                        "parameters": {
                            "type": "object",
                            "properties": properties,
                            "required": required,
                        },
                    },
                }
                schemas.append(schema)
            except Exception as e:
                logger.warning("为工具 %s 自动生成 schema 失败: %s", name, e)

        return schemas

    # ------------------------------------------------------------------
    # 内部：构造 messages
    # ------------------------------------------------------------------

    async def _build_initial_messages(
        self,
        user_input: str,
        user_id: str,
        enable_rag: bool,
    ) -> List[LLMMessage]:
        """
        基于 system_prompt + 历史记录 + RAG context + 用户输入 构造 messages
        """
        messages: List[LLMMessage] = []

        # 1. system prompt
        if self.cfg.system_prompt:
            messages.append(
                LLMMessage(role="system", content=self.cfg.system_prompt)
            )

        # 2. 加载历史记录（多轮对话上下文）
        history = self._load_conversation_history(user_id)
        if history:
            messages.extend(history)
            # 日志已在 _load_conversation_history 中输出
        else:
            logger.info(f"📚 无历史记录（user_id={user_id}，memory_enabled={self.cfg.memory_enabled}）")

        # 3. RAG 上下文（如果启用）
        if enable_rag and self.rag is not None:
            try:
                rag_resp, context = self.rag.query(
                    query_text=user_input,
                    user_id=user_id,
                    return_context=True,
                    max_context_docs=5,
                    max_context_chars=1800,
                )
                if context:
                    messages.append(
                        LLMMessage(
                            role="system",
                            content=(
                                "以下是知识库检索到的相关内容，请在回答时尽量参考：\n\n"
                                f"{context}"
                            ),
                        )
                    )
            except Exception as e:
                logger.error("RAG 查询失败，将在无知识库的情况下继续: %s", e)

        # 4. 用户输入
        messages.append(LLMMessage(role="user", content=user_input))

        return messages

    # ------------------------------------------------------------------
    # 内部：工具调用循环（function calling 风格）
    # ------------------------------------------------------------------

    async def _tool_call_loop(
        self,
        base_messages: List[LLMMessage],
        initial_response: LLMResponse,
        tools_schema: Optional[List[Dict[str, Any]]] = None,
    ) -> LLMResponse:
        """
        工具调用循环（OpenAI/Qwen 标准版）：
        每一轮：
          1) 读取上一轮的 tool_calls
          2) 把上一轮 assistant(tool_calls) 消息追加到 messages
          3) 针对每个 tool_call 生成对应的 role=tool 消息（带 tool_call_id）
          4) 再次调用 LLM，让模型整合工具结果
        满足规范要求：
          - 任意 tool 消息前，必须有一条带 tool_calls 的 assistant 消息
          - tool 消息必须带 tool_call_id 对应那条调用
        """
        messages = list(base_messages)
        last_response = initial_response

        for iteration in range(self.max_tool_iterations):
            tool_calls = last_response.tool_calls or []
            if not tool_calls:
                # 没有新的工具调用，直接返回当前回答
                return last_response

            logger.info(
                "工具调用回合 %d，检测到 %d 个 tool_calls",
                iteration + 1,
                len(tool_calls),
            )

            # 1) 把上一轮的 assistant(tool_calls) 消息追加
            messages.append(
                LLMMessage(
                    role="assistant",
                    content=last_response.content,
                    tool_calls=tool_calls or None,
                )
            )

            # 2) 执行工具，为每个 tool_call 生成一条 role=tool 的消息
            tool_messages = await self._execute_tool_calls(tool_calls)
            if tool_messages:
                messages.extend(tool_messages)

            # 3) 再次调用 LLM，让模型基于工具结果生成新内容/下一轮 tool_calls
            if tools_schema:
                last_response = await self.llm.chat(
                    messages,
                    tools=tools_schema,
                    tool_choice="auto",
                )
            else:
                last_response = await self.llm.chat(messages)

            # 这一轮如果没有新的 tool_calls，就可以返回最终回答
            if not last_response.tool_calls:
                return last_response

        logger.warning(
            "工具循环已达到最大迭代次数 %d，将返回最后一次响应。",
            self.max_tool_iterations,
        )
        return last_response


    async def _execute_tool_calls(
        self,
        tool_calls: List[Dict[str, Any]],
    ) -> List[LLMMessage]:
        """
        执行所有 tool_calls，为每个调用生成一条 role=tool 消息：
        - content: 工具执行结果（建议 JSON 字符串）
        - name: 工具名
        - tool_call_id: 对应的 tool_call["id"]
        """
        tool_messages: List[LLMMessage] = []

        if not self.tools:
            logger.warning("模型请求了工具调用，但当前 Agent 未注册任何工具。")
            return tool_messages

        async def _run_single(
            call_id: Optional[str],
            func_name: str,
            tool_fn: ToolCallable,
            args: Dict[str, Any],
        ) -> LLMMessage:
            try:
                result = await tool_fn(**args)
                content = json.dumps(result, ensure_ascii=False)
            except Exception as e:
                logger.error("工具 %s 执行异常: %s", func_name, e)
                content = json.dumps(
                    {"error": f"Exception during tool execution: {str(e)}"},
                    ensure_ascii=False,
                )
            # 返回一条标准 tool 消息
            return LLMMessage(
                role="tool",
                content=content,
                name=func_name,
                tool_call_id=call_id,
            )

        tasks = []

        for tc in tool_calls:
            try:
                call_id = tc.get("id")
                func = tc.get("function", {}) or {}
                func_name = func.get("name")
                raw_args = func.get("arguments", "")

                if not func_name:
                    logger.warning("tool_call 缺少函数名: %s", tc)
                    continue

                tool_fn = self.tools.get(func_name)
                if not tool_fn:
                    logger.warning("未找到工具函数: %s", func_name)
                    # 即便工具不存在，也可以返回一条工具错误消息
                    err_msg = LLMMessage(
                        role="tool",
                        content=json.dumps(
                            {"error": f"Tool '{func_name}' not registered on agent."},
                            ensure_ascii=False,
                        ),
                        name=func_name,
                        tool_call_id=call_id,
                    )
                    tool_messages.append(err_msg)
                    continue

                args = self._safe_parse_json(raw_args)
                tasks.append(_run_single(call_id, func_name, tool_fn, args))
            except Exception as e:
                logger.error("解析 tool_call 失败: %s", e)

        if tasks:
            results = await asyncio.gather(*tasks, return_exceptions=True)
            for r in results:
                if isinstance(r, Exception):
                    # 极端情况：_run_single 自身抛异常，不太可能但以防万一
                    logger.error("执行工具时发生未捕获异常: %s", r)
                else:
                    tool_messages.append(r)

        return tool_messages

    # async def _run_single_tool(
    #     self,
    #     name: str,
    #     fn: ToolCallable,
    #     args: Dict[str, Any],
    # ) -> Dict[str, Any]:
    #     """
    #     执行单个工具调用，统一包装结果格式。
    #     """
    #     try:
    #         result = await fn(**args)
    #         return {
    #             "tool": name,
    #             "success": True,
    #             "result": result,
    #         }
    #     except Exception as e:
    #         logger.error("工具 %s 执行异常: %s", name, e)
    #         return {
    #             "tool": name,
    #             "success": False,
    #             "result": f"Exception during tool execution: {e}",
    #         }

    @staticmethod
    def _safe_parse_json(raw: Any) -> Dict[str, Any]:
        if isinstance(raw, dict):
            return raw
        if not raw:
            return {}
        if isinstance(raw, str):
            try:
                return json.loads(raw)
            except json.JSONDecodeError:
                logger.warning("工具参数 JSON 解析失败，原始内容: %s", raw)
                return {}
        # 其它类型直接丢空
        logger.warning("工具参数类型异常: %r", raw)
        return {}
    
    # ------------------------------------------------------------------
    # 对话历史管理
    # ------------------------------------------------------------------
    
    def _load_conversation_history(self, user_id: str) -> List[LLMMessage]:
        """
        加载用户的对话历史（最近 N 轮 + 总结信息）
        
        Returns:
            历史消息列表，如果没有历史则返回空列表
        """
        if not self.cfg.memory_enabled:
            logger.debug(f"记忆功能已禁用（user_id={user_id}）")
            return []
        
        messages: List[LLMMessage] = []
        
        # 1. 如果有总结信息，先添加总结
        if user_id in self.user_summaries and self.user_summaries[user_id]:
            summary_message = LLMMessage(
                role="system",
                content=f"以下是之前对话的总结（关键信息）：\n\n{self.user_summaries[user_id]}"
            )
            messages.append(summary_message)
            logger.info(f"📝 已加载用户 {user_id} 的对话总结（长度={len(self.user_summaries[user_id])} 字符）")
        
        # 2. 加载最近的对话历史
        if user_id not in self.user_histories:
            logger.debug(f"用户 {user_id} 暂无历史记录")
            return messages
        
        history = self.user_histories[user_id]
        
        # 保留最近的 history_window 轮对话（每轮包含 user + assistant）
        max_messages = self.history_window * 2  # 每轮 2 条消息（user + assistant）
        if len(history) > max_messages:
            history = history[-max_messages:]
            self.user_histories[user_id] = history
        
        messages.extend(history)
        logger.info(f"📚 已加载用户 {user_id} 的 {len(history)} 条历史记录（{len(history)//2} 轮对话）")
        # 打印前几条历史记录的内容（用于调试）
        if history:
            preview = []
            for i, msg in enumerate(history[:4]):  # 只显示前4条
                role_preview = "用户" if msg.role == "user" else "助手"
                content_preview = (msg.content or "")[:50] + "..." if len(msg.content or "") > 50 else (msg.content or "")
                preview.append(f"{role_preview}: {content_preview}")
            logger.debug(f"历史记录预览: {' | '.join(preview)}")
        
        return messages
    
    def _save_conversation_history(
        self,
        user_id: str,
        user_input: str,
        response: LLMResponse,
    ) -> None:
        """
        保存对话历史（用户输入 + 助手回复）
        
        Args:
            user_id: 用户 ID
            user_input: 用户输入
            response: LLM 响应
        """
        logger.info(f"🔍 开始保存对话历史（user_id={user_id}, memory_enabled={self.cfg.memory_enabled}）")
        
        if not self.cfg.memory_enabled:
            logger.warning(f"⚠️ 记忆功能已禁用，跳过保存（user_id={user_id}）")
            return
        
        if user_id == "anonymous":
            # 匿名用户不保存历史
            logger.debug(f"匿名用户，跳过保存（user_id={user_id}）")
            return
        
        # 初始化用户历史记录
        if user_id not in self.user_histories:
            self.user_histories[user_id] = []
            logger.info(f"🆕 为新用户创建历史记录（user_id={user_id}）")
        
        history = self.user_histories[user_id]
        old_count = len(history)
        
        # 添加用户消息（确保历史记录中包含完整的对话对）
        user_message = LLMMessage(role="user", content=user_input)
        history.append(user_message)
        
        # 添加助手回复
        assistant_message = LLMMessage(
            role="assistant",
            content=response.content,
            tool_calls=response.tool_calls if response.tool_calls else None,
        )
        history.append(assistant_message)
        
        new_count = len(history)
        logger.info(f"✅ 已添加对话到历史（user_id={user_id}，历史记录数：{old_count} -> {new_count}）")
        
        # 检查是否需要总结历史记录
        # 当历史记录超过 summarize_threshold 轮时，触发总结
        current_rounds = len(history) // 2  # 每轮 2 条消息
        if (self.summarize_enabled and 
            current_rounds > self.summarize_threshold and 
            current_rounds % 2 == 0):  # 每 2 轮检查一次，避免频繁总结
            # 在后台异步执行总结，不阻塞当前请求
            asyncio.create_task(self._summarize_old_history(user_id, history.copy()))
        
        # 限制历史记录长度（保留最近的对话）
        max_messages = self.history_window * 2  # 每轮 2 条消息（user + assistant）
        if len(history) > max_messages:
            # 如果启用了总结，旧的历史已经被总结，这里只需要保留最近的
            # 如果没有启用总结，直接截断
            if not self.summarize_enabled:
                history = history[-max_messages:]
                self.user_histories[user_id] = history
        
        # 验证保存是否成功
        verify_count = len(self.user_histories.get(user_id, []))
        logger.info(f"💾 已保存对话历史（user_id={user_id}，当前历史长度={verify_count} 条消息，{verify_count//2} 轮对话）")
        
        # 打印保存的消息内容预览（用于调试）
        if len(history) >= 2:
            last_user_msg = history[-2].content[:50] if len(history[-2].content) > 50 else history[-2].content
            last_assistant_msg = history[-1].content[:50] if len(history[-1].content) > 50 else history[-1].content
            logger.debug(f"最新对话: 用户: {last_user_msg}... | 助手: {last_assistant_msg}...")
        
        # 再次验证：确保历史记录真的被保存了
        if user_id not in self.user_histories or len(self.user_histories[user_id]) == 0:
            logger.error(f"❌ 严重错误：保存后验证失败！user_id={user_id} 的历史记录为空！")
        else:
            logger.debug(f"✅ 保存验证成功：user_id={user_id} 有 {len(self.user_histories[user_id])} 条历史记录")
    
    async def _summarize_old_history(self, user_id: str, history: List[LLMMessage]) -> None:
        """
        总结旧的对话历史，提取关键信息
        
        策略：
        1. 保留最近的 N 轮完整对话（history_window）
        2. 将更早的对话总结成关键信息
        3. 将总结信息存储到 user_summaries 中
        4. 从 history 中删除已总结的部分
        
        Args:
            user_id: 用户 ID
            history: 完整的历史记录列表
        """
        if not self.summarize_enabled:
            return
        
        # 计算需要保留的最近对话数量
        keep_messages = self.history_window * 2  # 保留最近 N 轮的完整对话
        
        if len(history) <= keep_messages:
            # 历史记录还不够长，不需要总结
            return
        
        # 分离需要总结的旧历史和需要保留的最近历史
        old_history = history[:-keep_messages]  # 需要总结的部分
        recent_history = history[-keep_messages:]  # 需要保留的部分
        
        if not old_history:
            return
        
        try:
            # 构建总结提示词
            old_conversation_text = self._format_history_for_summary(old_history)
            
            summary_prompt = f"""请总结以下对话历史，提取关键信息。重点关注：
1. 用户的重要偏好、需求、背景信息
2. 讨论的主要话题和结论
3. 用户明确表达的重要信息（如姓名、目标、偏好等）
4. 任何需要后续记住的重要细节

对话历史：
{old_conversation_text}

请用简洁的中文总结关键信息，格式清晰，便于后续参考。"""
            
            # 调用 LLM 进行总结
            summary_messages = [
                LLMMessage(role="system", content="你是一个专业的对话总结助手，擅长提取关键信息。"),
                LLMMessage(role="user", content=summary_prompt)
            ]
            
            summary_response = await self.llm.chat(summary_messages, tools=None, tool_choice="none")
            new_summary = summary_response.content.strip()
            
            # 合并新的总结到现有总结中
            existing_summary = self.user_summaries.get(user_id, "")
            if existing_summary:
                # 如果已有总结，合并它们
                combined_summary = f"{existing_summary}\n\n---\n\n{new_summary}"
            else:
                combined_summary = new_summary
            
            # 限制总结长度（避免总结本身过长）
            max_summary_length = 1000  # 字符数限制
            if len(combined_summary) > max_summary_length:
                # 如果总结过长，只保留最新的部分
                combined_summary = combined_summary[-max_summary_length:]
            
            self.user_summaries[user_id] = combined_summary
            
            # 更新历史记录：只保留最近的部分
            self.user_histories[user_id] = recent_history
            
            logger.info(f"已总结用户 {user_id} 的旧对话历史（总结了 {len(old_history)} 条消息，保留 {len(recent_history)} 条）")
            
        except Exception as e:
            logger.error(f"总结对话历史失败（user_id={user_id}）: {e}", exc_info=True)
            # 总结失败时，回退到简单截断策略
            self.user_histories[user_id] = recent_history
    
    def _format_history_for_summary(self, history: List[LLMMessage]) -> str:
        """
        将历史记录格式化为适合总结的文本格式
        
        Args:
            history: 历史消息列表
            
        Returns:
            格式化的对话文本
        """
        lines = []
        for msg in history:
            role_name = "用户" if msg.role == "user" else "助手"
            content = msg.content or ""
            # 移除 tool_calls 信息（总结时不需要）
            lines.append(f"{role_name}: {content}")
        
        return "\n".join(lines)
    
    def clear_history(self, user_id: str) -> None:
        """
        清空指定用户的对话历史和总结
        
        Args:
            user_id: 用户 ID
        """
        if user_id in self.user_histories:
            del self.user_histories[user_id]
        if user_id in self.user_summaries:
            del self.user_summaries[user_id]
        logger.info(f"已清空用户 {user_id} 的对话历史和总结")
       

# ----------------------------------------------------------------------
# 工厂函数 & CLI Demo
# ----------------------------------------------------------------------

def create_agent(extra_tools: Optional[Dict[str, ToolCallable]] = None) -> Agent:
    """
    使用 ConfigManager 自动加载配置并创建 Agent
    """
    cfg_manager = ConfigManager()
    cfg = cfg_manager.get_config()
    return Agent(cfg, extra_tools=extra_tools)


# ------- 示例工具（可选）：你可以根据需要删掉或改写 -------

async def sample_time_tool() -> Dict[str, Any]:
    """示例工具：返回当前时间"""
    import datetime

    now = datetime.datetime.now().isoformat()
    return {"now": now}


async def sample_add_tool(a: float, b: float) -> Dict[str, Any]:
    """示例工具：返回 a + b"""
    return {"a": a, "b": b, "sum": a + b}


async def interactive_cli() -> None:
    """
    简单命令行交互 Demo：
    - 支持 RAG
    - 不开启工具调用（你可以按需改成 True）
    """
    logging.basicConfig(
        level=logging.INFO,
        format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
    )
        # 添加配置调试信息
    cfg_manager = ConfigManager()
    cfg = cfg_manager.get_config()
    print(f"=== 配置信息 ===")
    print(f"模型提供商: {cfg.model.provider}")
    print(f"模型名称: {cfg.model.model_name}")
    print(f"API Base URL: {cfg.model.base_url}")
    print(f"API Key 前几位: {cfg.model.api_key[:10] if cfg.model.api_key else '未设置'}")
    print(f"超时时间: {cfg.model.timeout}秒")
    print("================")

    # 注册两个示例工具（如果不需要工具，可以传空 dict）
    tools = {
        "get_time": sample_time_tool,
        "add_numbers": sample_add_tool,
    }

    agent = create_agent(extra_tools=tools)

    print("=== Agent CLI ===")
    print("输入内容并回车，输入 '/exit' 退出。")
    while True:
        user_input = input("\nYou: ").strip()
        if user_input.lower() in {"/exit", "exit", "quit"}:
            print("Bye.")
            break

        try:
            resp = await agent.chat(
                user_input=user_input,
                user_id="cli_user",
                enable_rag=True,
                enable_tools=True,  # 如果暂时不想测工具，可以改成 False
            )
            print(f"Agent: {resp.content}")
        except Exception as e:
            print(f"[Error] {e}")


if __name__ == "__main__":
    asyncio.run(interactive_cli())