#!/bin/bash

# Web 应用启动脚本

echo "🚀 启动智能投资顾问 Agent Web 应用..."
echo ""

# 检查是否在正确的目录
if [ ! -f "web.py" ]; then
    echo "❌ 错误: 请在 src 目录下运行此脚本"
    exit 1
fi

# 检查环境变量
if [ -z "$QWEN_API_KEY" ] && [ -z "$OPENAI_API_KEY" ] && [ -z "$DEEPSEEK_API_KEY" ]; then
    echo "⚠️  警告: 未检测到 API Key 环境变量"
    echo "请设置以下环境变量之一:"
    echo "  export QWEN_API_KEY='your-key'"
    echo "  export OPENAI_API_KEY='your-key'"
    echo "  export DEEPSEEK_API_KEY='your-key'"
    echo ""
fi

# 启动 Web 应用
echo "✅ 启动 Web 服务器..."
echo "📱 访问地址: http://localhost:8080"
echo "按 Ctrl+C 停止服务器"
echo ""

python -m uvicorn web:app --host 0.0.0.0 --port 8080 --reload

