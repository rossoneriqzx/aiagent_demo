# LangGraph 入门教程（基于你的项目）

## 📚 目录

1. [什么是 LangGraph？](#什么是-langgraph)
2. [核心概念](#核心概念)
3. [对比：传统方式 vs LangGraph](#对比传统方式-vs-langgraph)
4. [实战：重构你的 RAG 工作流](#实战重构你的-rag-工作流)
5. [进阶：多 Agent 协作](#进阶多-agent-协作)
6. [最佳实践](#最佳实践)

---

## 什么是 LangGraph？

**LangGraph** 是 LangChain 团队开发的**状态机/工作流框架**，专门用于构建**有状态、多步骤的 AI 应用**。

### 为什么需要 LangGraph？

你的 `agent.py` 中已经有这样的流程：

```python
# 传统方式（agent.py 中的流程）
async def chat():
    1. 构建 messages（历史 + RAG 上下文）
    2. 调用 LLM
    3. 如果有工具调用 -> 执行工具 -> 再次调用 LLM（循环）
    4. 保存历史
```

这种方式的问题：
- ❌ 流程逻辑分散在 if/else 中，难以维护
- ❌ 无法可视化流程
- ❌ 难以暂停/恢复/回放
- ❌ 多 Agent 协作时，代码会变得很复杂

**LangGraph 的优势：**
- ✅ 用**图**清晰表达流程
- ✅ 每个步骤是**独立的节点**，易于测试和修改
- ✅ 内置**检查点**，支持暂停/恢复/回放
- ✅ 支持**条件路由**（根据状态决定下一步）
- ✅ 可以**可视化**整个工作流

---

## 核心概念

### 1. State（状态）

**State** 是工作流中传递的数据容器，通常用 `TypedDict` 定义：

```python
from typing import TypedDict, List, Annotated
from langgraph.graph.message import add_messages

class ChatState(TypedDict):
    messages: Annotated[List[LLMMessage], add_messages]  # 消息列表
    user_input: str  # 用户输入
    rag_context: str  # RAG 上下文
```

**关键点：**
- `Annotated[List[LLMMessage], add_messages]` 表示这个字段会自动追加（不是替换）
- 其他字段默认是**替换**（返回新值会覆盖旧值）

### 2. Node（节点）

**Node** 是一个函数，接收 `state`，返回 `state`（或部分字段）：

```python
def my_node(state: ChatState) -> ChatState:
    # 读取 state
    user_input = state["user_input"]
    
    # 处理逻辑
    result = do_something(user_input)
    
    # 返回更新后的 state（可以是完整 state 或部分字段）
    return {
        "rag_context": result,  # 只更新这个字段
    }
```

### 3. Graph（图）

**Graph** 把节点和边连接起来：

```python
from langgraph.graph import StateGraph, END

# 1. 创建图构建器
builder = StateGraph(ChatState)

# 2. 添加节点
builder.add_node("node1", my_node)
builder.add_node("node2", another_node)

# 3. 设置入口点
builder.set_entry_point("node1")

# 4. 添加边（连接节点）
builder.add_edge("node1", "node2")  # node1 -> node2
builder.add_edge("node2", END)      # node2 -> 结束

# 5. 编译图
graph = builder.compile()
```

### 4. Conditional Edges（条件边）

根据 state 决定下一步走哪个分支：

```python
def should_use_rag(state: ChatState) -> Literal["retrieve", "skip"]:
    """返回下一步的节点名"""
    if len(state["user_input"]) < 5:
        return "skip"  # 跳过 RAG
    return "retrieve"  # 使用 RAG

# 添加条件边
builder.add_conditional_edges(
    "rewrite_query",
    should_use_rag,  # 判断函数
    {
        "retrieve": "retrieve_node",  # 如果返回 "retrieve"，去 retrieve_node
        "skip": "generate_node",      # 如果返回 "skip"，去 generate_node
    }
)
```

### 5. Checkpointer（检查点）

**检查点**用于持久化 state，支持：
- 恢复会话（用 `thread_id`）
- 回放流程
- 调试和审计

```python
from langgraph.checkpoint import MemorySaver

# 内存检查点（生产环境可以用 Redis/PostgreSQL）
memory = MemorySaver()
graph = builder.compile(checkpointer=memory)

# 运行图（使用 thread_id）
result = graph.invoke(
    initial_state,
    config={"configurable": {"thread_id": "user-123"}}
)

# 后续可以恢复这个会话
result2 = graph.invoke(
    {"messages": [LLMMessage(role="user", content="继续对话")]},
    config={"configurable": {"thread_id": "user-123"}}  # 同一个 thread_id
)
```

---

## 对比：传统方式 vs LangGraph

### 传统方式（你的 agent.py）

```python
async def chat(self, user_input: str, user_id: str):
    # 1. 构建 messages
    messages = await self._build_initial_messages(user_input, user_id, enable_rag=True)
    
    # 2. 调用 LLM
    response = await self.llm.chat(messages, tools=tools_schema)
    
    # 3. 工具调用循环（嵌套在 if 里）
    if tools_schema and response.tool_calls:
        response = await self._tool_call_loop(messages, response, tools_schema)
    
    # 4. 保存历史
    self._save_conversation_history(user_id, user_input, response)
    
    return response
```

**问题：**
- 流程是线性的，难以扩展
- 工具调用循环是硬编码的
- 无法暂停/恢复
- 难以可视化

### LangGraph 方式

```python
# 定义状态
class AgentState(TypedDict):
    messages: Annotated[List[LLMMessage], add_messages]
    user_input: str
    tool_calls: List[dict]

# 定义节点
def build_messages_node(state: AgentState) -> AgentState:
    # 构建 messages 的逻辑
    return {"messages": [...]}

def llm_node(state: AgentState) -> AgentState:
    # 调用 LLM
    return {"messages": [assistant_message]}

def tools_node(state: AgentState) -> AgentState:
    # 执行工具
    return {"messages": [tool_messages]}

# 构建图
builder = StateGraph(AgentState)
builder.add_node("build_messages", build_messages_node)
builder.add_node("llm", llm_node)
builder.add_node("tools", tools_node)

builder.set_entry_point("build_messages")
builder.add_edge("build_messages", "llm")
builder.add_conditional_edges(
    "llm",
    lambda s: "tools" if s.get("tool_calls") else "end",
    {"tools": "tools", "end": END}
)
builder.add_edge("tools", "llm")  # 工具执行后，继续调用 LLM

graph = builder.compile()
```

**优势：**
- ✅ 流程清晰，每个步骤独立
- ✅ 可以可视化（`graph.get_graph().draw_mermaid()`）
- ✅ 支持检查点，可以暂停/恢复
- ✅ 易于扩展（添加新节点即可）

---

## 实战：重构你的 RAG 工作流

### 你的现有流程（rag.py + agent.py）

```
用户输入 
  -> RAG 检索（rag.query）
  -> 构建 messages（包含 RAG 上下文）
  -> 调用 LLM
  -> 返回结果
```

### LangGraph 版本

```python
class RAGState(TypedDict):
    messages: Annotated[List[LLMMessage], add_messages]
    user_input: str
    user_id: str
    rag_context: str
    documents: List[dict]
    final_answer: str

# 节点 1：重写查询（可选）
def rewrite_query_node(state: RAGState) -> RAGState:
    # 可以在这里用 LLM 重写查询，让它更适合检索
    return {"user_input": enhanced_query}

# 节点 2：检索文档
def retrieve_node(state: RAGState) -> RAGState:
    rag = create_enhanced_rag_pipeline(cfg)
    response, context = rag.query(
        query_text=state["user_input"],
        user_id=state["user_id"],
        return_context=True,
    )
    return {
        "rag_context": context,
        "documents": [{"id": d.id, "text": d.text, ...} for d in response.documents],
    }

# 节点 3：生成答案
def generate_node(state: RAGState) -> RAGState:
    messages = build_messages_with_rag(state)
    response = llm.chat(messages)
    return {
        "final_answer": response.content,
        "messages": [user_msg, assistant_msg],
    }

# 构建图
builder = StateGraph(RAGState)
builder.add_node("rewrite", rewrite_query_node)
builder.add_node("retrieve", retrieve_node)
builder.add_node("generate", generate_node)

builder.set_entry_point("rewrite")
builder.add_edge("rewrite", "retrieve")
builder.add_edge("retrieve", "generate")
builder.add_edge("generate", END)

graph = builder.compile()
```

**运行：**

```python
initial_state = {
    "messages": [],
    "user_input": "什么是投资组合？",
    "user_id": "web_user",
    "rag_context": "",
    "documents": [],
    "final_answer": "",
}

result = graph.invoke(initial_state)
print(result["final_answer"])
```

---

## 进阶：多 Agent 协作

### 场景：研究助手 + 代码生成器 + 审查员

```python
class MultiAgentState(TypedDict):
    messages: Annotated[List[LLMMessage], add_messages]
    current_agent: str  # "researcher", "coder", "reviewer"
    task: str

def researcher_node(state: MultiAgentState) -> MultiAgentState:
    # 研究任务，生成报告
    return {"messages": [research_report], "current_agent": "coder"}

def coder_node(state: MultiAgentState) -> MultiAgentState:
    # 根据研究报告生成代码
    return {"messages": [code], "current_agent": "reviewer"}

def reviewer_node(state: MultiAgentState) -> MultiAgentState:
    # 审查代码
    return {"messages": [review], "current_agent": "end"}

# 构建图
builder = StateGraph(MultiAgentState)
builder.add_node("researcher", researcher_node)
builder.add_node("coder", coder_node)
builder.add_node("reviewer", reviewer_node)

builder.set_entry_point("researcher")

# 根据 current_agent 决定下一步
def route_agent(state: MultiAgentState) -> str:
    return state["current_agent"]

builder.add_conditional_edges("researcher", route_agent, {
    "coder": "coder",
    "end": END,
})
builder.add_conditional_edges("coder", route_agent, {
    "reviewer": "reviewer",
    "end": END,
})
builder.add_conditional_edges("reviewer", route_agent, {
    "end": END,
})

graph = builder.compile()
```

---

## 最佳实践

### 1. 状态设计

- ✅ 使用 `TypedDict` 明确类型
- ✅ 用 `Annotated[List, add_messages]` 自动追加消息
- ✅ 避免在 state 中存储大对象（如完整的向量库）

### 2. 节点设计

- ✅ 每个节点职责单一
- ✅ 节点函数应该是**纯函数**（尽量不依赖外部状态）
- ✅ 返回部分 state 即可（LangGraph 会自动合并）

### 3. 错误处理

```python
def safe_node(state: ChatState) -> ChatState:
    try:
        result = risky_operation(state)
        return {"result": result}
    except Exception as e:
        logger.error(f"节点执行失败: {e}")
        return {"error": str(e)}  # 可以在 state 中记录错误
```

### 4. 检查点使用

```python
# 生产环境建议用持久化检查点
from langgraph.checkpoint.postgres import PostgresSaver

checkpointer = PostgresSaver.from_conn_string("postgresql://...")
graph = builder.compile(checkpointer=checkpointer)

# 使用 thread_id 标识会话
result = graph.invoke(
    state,
    config={"configurable": {"thread_id": f"user-{user_id}"}}
)
```

### 5. 可视化

```python
# 生成 Mermaid 图（可以在 Markdown 中渲染）
mermaid_graph = graph.get_graph().draw_mermaid()
print(mermaid_graph)

# 或者保存为图片（需要安装 graphviz）
graph.get_graph().draw_ascii()
```

---

## 下一步

1. **运行示例代码**：`python src/langgraph_demo.py`
2. **阅读官方文档**：https://langgraph.readthedocs.io
3. **尝试重构**：把你现有的 `agent.py` 中的某个流程改成 LangGraph 版本
4. **探索高级特性**：
   - Streaming（流式输出）
   - Human-in-the-loop（人工审核节点）
   - 子图（Graph 嵌套）

---

## 常见问题

### Q: LangGraph 和 LangChain 是什么关系？

A: LangGraph 是 LangChain 的扩展，专注于**工作流编排**。你可以继续使用 LangChain 的模型、工具、向量库等组件，只是用 LangGraph 来编排它们。

### Q: 性能如何？

A: LangGraph 本身开销很小，主要是图遍历。性能瓶颈通常在 LLM 调用和向量检索，这些和传统方式一样。

### Q: 可以异步吗？

A: 可以！节点函数可以是 `async def`，LangGraph 支持异步执行。

### Q: 如何调试？

A: 
- 使用检查点回放流程
- 在每个节点中打印 state
- 使用 `graph.get_graph().draw_mermaid()` 可视化流程

---

祝你学习愉快！🚀

