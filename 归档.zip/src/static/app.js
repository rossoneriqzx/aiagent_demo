// 全局变量
let currentUser = 'web_user';
let isStreaming = false;

// DOM 元素
const chatMessages = document.getElementById('chat-messages');
const messageInput = document.getElementById('message-input');
const sendButton = document.getElementById('send-button');
const statusIndicator = document.getElementById('status-indicator');
const statusText = document.getElementById('status-text');

// 初始化
document.addEventListener('DOMContentLoaded', async () => {
    await checkHealth();
    await loadConfig();
    setupEventListeners();
});

// 设置事件监听
function setupEventListeners() {
    messageInput.addEventListener('input', () => {
        // 自动调整高度
        messageInput.style.height = 'auto';
        messageInput.style.height = messageInput.scrollHeight + 'px';
    });
}

// 健康检查
async function checkHealth() {
    try {
        const response = await fetch('/api/health');
        const data = await response.json();
        if (data.status === 'ok') {
            updateStatus('已连接', 'success');
        }
    } catch (error) {
        updateStatus('连接失败', 'error');
        console.error('健康检查失败:', error);
    }
}

// 加载配置
async function loadConfig() {
    try {
        const response = await fetch('/api/config');
        const config = await response.json();
        
        const configInfo = document.getElementById('config-info');
        configInfo.innerHTML = `
            <p><strong>模型:</strong> ${config.model_provider} / ${config.model_name}</p>
            <p><strong>知识库:</strong> ${config.knowledge_base_enabled ? '✅ 已启用' : '❌ 未启用'}</p>
            <p><strong>MCP 工具:</strong> ${config.mcp_enabled ? '✅ 已启用' : '❌ 未启用'}</p>
        `;
    } catch (error) {
        console.error('加载配置失败:', error);
    }
}

// 更新状态
function updateStatus(text, type) {
    statusText.textContent = text;
    if (type === 'success') {
        statusIndicator.style.color = '#4ade80';
    } else if (type === 'error') {
        statusIndicator.style.color = '#ef4444';
    }
}

// 切换配置面板
function toggleConfig() {
    const content = document.getElementById('config-content');
    content.style.display = content.style.display === 'none' ? 'block' : 'none';
}

// 处理键盘事件
function handleKeyDown(event) {
    if (event.key === 'Enter' && !event.shiftKey) {
        event.preventDefault();
        sendMessage();
    }
}

// 发送消息
async function sendMessage() {
    const message = messageInput.value.trim();
    if (!message || isStreaming) {
        return;
    }

    // 添加用户消息到界面
    addMessage('user', message);
    messageInput.value = '';
    messageInput.style.height = 'auto';

    // 禁用输入
    setInputDisabled(true);

    // 获取配置选项
    const enableRag = document.getElementById('enable-rag').checked;
    const enableTools = document.getElementById('enable-tools').checked;
    const enableStream = document.getElementById('enable-stream').checked;

    try {
        if (enableStream) {
            await sendMessageStream(message, enableRag, enableTools);
        } else {
            await sendMessageNormal(message, enableRag, enableTools);
        }
    } catch (error) {
        console.error('发送消息失败:', error);
        addMessage('assistant', `❌ 错误: ${error.message}`);
    } finally {
        setInputDisabled(false);
    }
}

// 普通模式发送消息
async function sendMessageNormal(message, enableRag, enableTools) {
    const response = await fetch('/api/chat', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            message: message,
            user_id: currentUser,
            enable_rag: enableRag,
            enable_tools: enableTools,
        }),
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || '请求失败');
    }

    const data = await response.json();
    addMessage('assistant', data.content, data);
}

// 流式模式发送消息
async function sendMessageStream(message, enableRag, enableTools) {
    isStreaming = true;
    const response = await fetch('/api/chat/stream', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
        },
        body: JSON.stringify({
            message: message,
            user_id: currentUser,
            enable_rag: enableRag,
            enable_tools: enableTools,
        }),
    });

    if (!response.ok) {
        const error = await response.json();
        throw new Error(error.detail || '请求失败');
    }

    const reader = response.body.getReader();
    const decoder = new TextDecoder();
    let buffer = '';
    let assistantMessageId = null;

    try {
        while (true) {
            const { done, value } = await reader.read();
            if (done) break;

            buffer += decoder.decode(value, { stream: true });
            const lines = buffer.split('\n');
            buffer = lines.pop() || '';

            for (const line of lines) {
                if (line.startsWith('data: ')) {
                    const data = JSON.parse(line.slice(6));
                    
                    if (data.type === 'start') {
                        assistantMessageId = addMessage('assistant', '', null, true);
                    } else if (data.type === 'chunk') {
                        appendToMessage(assistantMessageId, data.content);
                    } else if (data.type === 'usage') {
                        // 可以显示 token 使用情况
                        console.log('Token usage:', data.usage);
                    } else if (data.type === 'done') {
                        finalizeMessage(assistantMessageId);
                    } else if (data.type === 'error') {
                        updateMessage(assistantMessageId, `❌ 错误: ${data.message}`);
                    }
                }
            }
        }
    } finally {
        isStreaming = false;
    }
}

// 添加消息到界面
function addMessage(role, content, metadata = null, isStreaming = false) {
    const messageDiv = document.createElement('div');
    messageDiv.className = `message ${role}-message`;
    
    const contentDiv = document.createElement('div');
    contentDiv.className = 'message-content';
    contentDiv.id = `msg-${Date.now()}-${Math.random()}`;
    
    if (isStreaming) {
        contentDiv.innerHTML = '<div class="typing-indicator"><span></span><span></span><span></span></div>';
    } else if (content) {
        contentDiv.innerHTML = formatMessage(content);
    }
    
    // 添加元数据
    if (metadata && (metadata.tool_calls || metadata.usage)) {
        const metaDiv = document.createElement('div');
        metaDiv.className = 'message-meta';
        
        if (metadata.tool_calls && metadata.tool_calls.length > 0) {
            metaDiv.innerHTML += `🔧 调用了 ${metadata.tool_calls.length} 个工具 `;
        }
        if (metadata.usage) {
            metaDiv.innerHTML += `📊 Tokens: ${metadata.usage.total_tokens || 0}`;
        }
        contentDiv.appendChild(metaDiv);
    }
    
    messageDiv.appendChild(contentDiv);
    chatMessages.appendChild(messageDiv);
    
    // 滚动到底部
    scrollToBottom();
    
    return contentDiv.id;
}

// 更新消息内容（流式）
function appendToMessage(messageId, content) {
    const messageEl = document.getElementById(messageId);
    if (!messageEl) return;
    
    // 移除打字指示器
    const typingIndicator = messageEl.querySelector('.typing-indicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
    
    // 追加内容
    const existingContent = messageEl.innerHTML;
    messageEl.innerHTML = existingContent + escapeHtml(content);
    
    scrollToBottom();
}

// 完成消息（流式结束）
function finalizeMessage(messageId) {
    const messageEl = document.getElementById(messageId);
    if (!messageEl) return;
    
    const typingIndicator = messageEl.querySelector('.typing-indicator');
    if (typingIndicator) {
        typingIndicator.remove();
    }
}

// 更新消息（错误情况）
function updateMessage(messageId, content) {
    const messageEl = document.getElementById(messageId);
    if (!messageEl) return;
    messageEl.innerHTML = formatMessage(content);
}

// 格式化消息内容
function formatMessage(content) {
    // 简单的 Markdown 支持
    content = escapeHtml(content);
    
    // 代码块
    content = content.replace(/```(\w+)?\n([\s\S]*?)```/g, (match, lang, code) => {
        return `<pre><code>${code.trim()}</code></pre>`;
    });
    
    // 行内代码
    content = content.replace(/`([^`]+)`/g, '<code>$1</code>');
    
    // 换行
    content = content.replace(/\n/g, '<br>');
    
    // 链接
    content = content.replace(/(https?:\/\/[^\s]+)/g, '<a href="$1" target="_blank">$1</a>');
    
    return content;
}

// HTML 转义
function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// 滚动到底部
function scrollToBottom() {
    chatMessages.scrollTop = chatMessages.scrollHeight;
}

// 设置输入禁用状态
function setInputDisabled(disabled) {
    messageInput.disabled = disabled;
    sendButton.disabled = disabled;
    
    if (disabled) {
        sendButton.innerHTML = '<span>发送中...</span>';
    } else {
        sendButton.innerHTML = '<span>发送</span>';
    }
}

