"""
LangGraph 入门示例 - 基于你的项目结构

这个文件展示了：
1. LangGraph 基础概念（State、Node、Graph）
2. 如何用 LangGraph 重构你的 RAG + Agent 工作流
3. 对比传统方式 vs LangGraph 方式的区别

运行方式：
    python src/langgraph_demo.py
"""

from __future__ import annotations

import asyncio
import logging
from typing import Annotated, List, Literal, TypedDict

# LangGraph 核心导入
from langgraph.graph import StateGraph, END
from langgraph.checkpoint import MemorySaver
from langgraph.graph.message import add_messages

# 使用你现有的模块
from config import ConfigManager, AgentConfig
from llm_client import create_llm_client, LLMMessage, LLMResponse
from rag import create_enhanced_rag_pipeline, EnhancedRAGPipeline

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)


# ============================================================================
# 第一部分：LangGraph 基础概念（最小示例）
# ============================================================================

class SimpleChatState(TypedDict):
    """最简单的聊天状态：只包含消息列表"""
    messages: Annotated[List[LLMMessage], add_messages]


def simple_llm_node(state: SimpleChatState) -> SimpleChatState:
    """
    节点函数：调用 LLM 生成回复
    
    注意：
    - 输入是 state（TypedDict）
    - 返回也是 state（可以是完整 state 或部分字段）
    - LangGraph 会自动合并返回的字段到 state
    """
    messages = state["messages"]
    
    # 使用你现有的 LLM 客户端
    cfg_manager = ConfigManager()
    cfg = cfg_manager.get_config()
    llm = create_llm_client(cfg.model)
    
    # 同步调用（简化示例，实际可以用异步）
    # 注意：这里为了演示，我们简化了异步处理
    response = asyncio.run(llm.chat(messages))
    
    # 返回新的消息（LangGraph 会自动追加到 messages 列表）
    return {
        "messages": [
            LLMMessage(role="assistant", content=response.content)
        ]
    }


def create_simple_chat_graph():
    """
    创建最简单的聊天图：
    用户输入 -> LLM 回复 -> 结束
    """
    # 1. 创建图构建器
    builder = StateGraph(SimpleChatState)
    
    # 2. 添加节点
    builder.add_node("llm", simple_llm_node)
    
    # 3. 设置入口点
    builder.set_entry_point("llm")
    
    # 4. 添加边（从 llm 到结束）
    builder.add_edge("llm", END)
    
    # 5. 编译图（可选：添加检查点用于持久化）
    memory = MemorySaver()  # 内存检查点（生产环境可以用 Redis/PostgreSQL）
    graph = builder.compile(checkpointer=memory)
    
    return graph


# ============================================================================
# 第二部分：RAG 工作流（基于你的项目）
# ============================================================================

class RAGState(TypedDict):
    """RAG 工作流的状态"""
    messages: Annotated[List[LLMMessage], add_messages]
    user_input: str
    user_id: str
    rag_context: str  # RAG 检索到的上下文
    documents: List[dict]  # 检索到的文档列表
    final_answer: str  # 最终答案


def rewrite_query_node(state: RAGState) -> RAGState:
    """
    节点 1：重写查询（可选，让查询更适合检索）
    
    在实际项目中，这一步可以：
    - 扩展查询（添加同义词）
    - 提取关键词
    - 根据对话历史改写查询
    """
    user_input = state["user_input"]
    logger.info(f"📝 [重写查询] 原始查询: {user_input}")
    
    # 简化版：直接使用原查询（你可以在这里加 LLM 重写逻辑）
    rewritten = user_input
    
    return {
        "user_input": rewritten,  # 更新查询
    }


def retrieve_documents_node(state: RAGState) -> RAGState:
    """
    节点 2：检索文档（使用你现有的 RAG 系统）
    """
    user_input = state["user_input"]
    user_id = state.get("user_id", "web_user")
    
    logger.info(f"🔍 [检索文档] 查询: {user_input}, user_id: {user_id}")
    
    # 使用你现有的 RAG pipeline
    cfg_manager = ConfigManager()
    cfg = cfg_manager.get_config()
    rag = create_enhanced_rag_pipeline(cfg)
    
    # 执行检索
    rag_response, context = rag.query(
        query_text=user_input,
        user_id=user_id,
        return_context=True,
        max_context_docs=5,
        max_context_chars=1800,
    )
    
    # 格式化文档信息
    docs_info = [
        {
            "id": doc.id,
            "text": doc.text[:100] + "..." if len(doc.text) > 100 else doc.text,
            "score": doc.score,
            "source": doc.source,
        }
        for doc in rag_response.documents
    ]
    
    logger.info(f"✅ [检索完成] 找到 {len(rag_response.documents)} 个相关文档")
    
    return {
        "rag_context": context,
        "documents": docs_info,
    }


def generate_answer_node(state: RAGState) -> RAGState:
    """
    节点 3：生成答案（结合 RAG 上下文 + 对话历史）
    """
    user_input = state["user_input"]
    rag_context = state.get("rag_context", "")
    messages = state.get("messages", [])
    user_id = state.get("user_id", "web_user")
    
    logger.info(f"🤖 [生成答案] 查询: {user_input}")
    
    # 构建完整的 messages（包含 RAG 上下文）
    full_messages: List[LLMMessage] = []
    
    # 1. System prompt
    cfg_manager = ConfigManager()
    cfg = cfg_manager.get_config()
    if cfg.system_prompt:
        full_messages.append(LLMMessage(role="system", content=cfg.system_prompt))
    
    # 2. RAG 上下文（如果有）
    if rag_context:
        full_messages.append(
            LLMMessage(
                role="system",
                content=f"以下是知识库检索到的相关内容，请在回答时尽量参考：\n\n{rag_context}",
            )
        )
    
    # 3. 历史消息（如果有）
    full_messages.extend(messages)
    
    # 4. 当前用户输入
    full_messages.append(LLMMessage(role="user", content=user_input))
    
    # 调用 LLM
    llm = create_llm_client(cfg.model)
    response = asyncio.run(llm.chat(full_messages))
    
    logger.info(f"✅ [答案生成完成] 长度: {len(response.content)} 字符")
    
    return {
        "final_answer": response.content,
        "messages": [
            LLMMessage(role="user", content=user_input),
            LLMMessage(role="assistant", content=response.content),
        ],
    }


def should_use_rag(state: RAGState) -> Literal["retrieve", "skip_rag"]:
    """
    条件边函数：决定是否使用 RAG
    
    返回：
        - "retrieve": 需要检索，走 RAG 流程
        - "skip_rag": 跳过 RAG，直接生成答案
    """
    user_input = state["user_input"]
    
    # 简单规则：如果查询很短或包含特定关键词，跳过 RAG
    skip_keywords = ["你好", "谢谢", "再见", "帮助"]
    if any(kw in user_input for kw in skip_keywords) or len(user_input) < 5:
        logger.info("⏭️ [条件判断] 跳过 RAG，直接生成答案")
        return "skip_rag"
    
    logger.info("✅ [条件判断] 使用 RAG 检索")
    return "retrieve"


def create_rag_graph():
    """
    创建 RAG 工作流图：
    
    用户输入 -> 重写查询 -> [条件判断] -> 检索文档 -> 生成答案 -> 结束
                                    |                    |
                                    └-> 跳过 RAG ---------┘
    """
    builder = StateGraph(RAGState)
    
    # 添加节点
    builder.add_node("rewrite_query", rewrite_query_node)
    builder.add_node("retrieve", retrieve_documents_node)
    builder.add_node("generate", generate_answer_node)
    
    # 设置入口点
    builder.set_entry_point("rewrite_query")
    
    # 添加边
    builder.add_edge("rewrite_query", "retrieve")  # 重写后总是检索（简化版）
    # 或者用条件边：
    # builder.add_conditional_edges(
    #     "rewrite_query",
    #     should_use_rag,
    #     {
    #         "retrieve": "retrieve",
    #         "skip_rag": "generate",
    #     }
    # )
    
    builder.add_edge("retrieve", "generate")
    builder.add_edge("generate", END)
    
    # 编译（带检查点）
    memory = MemorySaver()
    graph = builder.compile(checkpointer=memory)
    
    return graph


# ============================================================================
# 第三部分：带工具调用的 Agent 工作流
# ============================================================================

class AgentState(TypedDict):
    """Agent 工作流状态（支持工具调用）"""
    messages: Annotated[List[LLMMessage], add_messages]
    user_input: str
    user_id: str
    tool_calls: List[dict]  # 当前轮的工具调用
    tool_results: List[dict]  # 工具执行结果
    iteration_count: int  # 工具调用迭代次数


def agent_think_node(state: AgentState) -> AgentState:
    """
    节点：Agent 思考（调用 LLM，可能返回工具调用）
    """
    messages = state["messages"]
    iteration = state.get("iteration_count", 0)
    max_iterations = 3
    
    if iteration >= max_iterations:
        logger.warning(f"⚠️ 达到最大迭代次数 {max_iterations}，停止工具调用")
        return state
    
    logger.info(f"🤔 [Agent思考] 迭代 {iteration + 1}/{max_iterations}")
    
    cfg_manager = ConfigManager()
    cfg = cfg_manager.get_config()
    llm = create_llm_client(cfg.model)
    
    # 准备工具 schema（简化版，实际可以从配置加载）
    tools_schema = None  # 这里可以添加工具定义
    
    response = asyncio.run(llm.chat(messages, tools=tools_schema, tool_choice="auto"))
    
    # 更新消息
    new_messages = [
        LLMMessage(
            role="assistant",
            content=response.content,
            tool_calls=response.tool_calls if response.tool_calls else None,
        )
    ]
    
    return {
        "messages": new_messages,
        "tool_calls": response.tool_calls or [],
        "iteration_count": iteration + 1,
    }


def execute_tools_node(state: AgentState) -> AgentState:
    """
    节点：执行工具调用
    """
    tool_calls = state.get("tool_calls", [])
    
    if not tool_calls:
        logger.info("✅ 没有工具调用，直接返回")
        return state
    
    logger.info(f"🔧 [执行工具] 共 {len(tool_calls)} 个工具调用")
    
    # 这里应该执行实际的工具调用
    # 简化版：模拟工具结果
    tool_results = []
    for tc in tool_calls:
        func_name = tc.get("function", {}).get("name", "unknown")
        logger.info(f"   - 执行工具: {func_name}")
        # 实际应该调用对应的工具函数
        tool_results.append({
            "tool_call_id": tc.get("id"),
            "result": f"工具 {func_name} 的执行结果（模拟）",
        })
    
    # 构造 tool 消息
    tool_messages = [
        LLMMessage(
            role="tool",
            content=str(result["result"]),
            tool_call_id=result["tool_call_id"],
        )
        for result in tool_results
    ]
    
    return {
        "messages": tool_messages,
        "tool_results": tool_results,
    }


def should_continue_tools(state: AgentState) -> Literal["think", "end"]:
    """
    条件边：判断是否继续工具调用循环
    """
    tool_calls = state.get("tool_calls", [])
    iteration = state.get("iteration_count", 0)
    
    if not tool_calls:
        logger.info("✅ [条件判断] 没有工具调用，结束流程")
        return "end"
    
    if iteration >= 3:
        logger.warning("⚠️ [条件判断] 达到最大迭代次数，结束流程")
        return "end"
    
    logger.info("🔄 [条件判断] 继续工具调用循环")
    return "think"


def create_agent_graph():
    """
    创建带工具调用的 Agent 图：
    
    用户输入 -> Agent思考 -> [有工具调用?] -> 执行工具 -> Agent思考 -> ...
                                    |                              |
                                    └-> 无工具调用 -> 结束          └-> 继续循环
    """
    builder = StateGraph(AgentState)
    
    builder.add_node("think", agent_think_node)
    builder.add_node("tools", execute_tools_node)
    
    builder.set_entry_point("think")
    
    # 条件边：根据是否有工具调用决定下一步
    builder.add_conditional_edges(
        "think",
        should_continue_tools,
        {
            "think": "tools",  # 有工具调用 -> 执行工具
            "end": END,  # 无工具调用 -> 结束
        }
    )
    
    builder.add_edge("tools", "think")  # 工具执行后，继续思考
    
    memory = MemorySaver()
    graph = builder.compile(checkpointer=memory)
    
    return graph


# ============================================================================
# 使用示例
# ============================================================================

async def demo_simple_chat():
    """演示 1：最简单的聊天图"""
    print("\n" + "="*60)
    print("演示 1：最简单的聊天图")
    print("="*60)
    
    graph = create_simple_chat_graph()
    
    # 初始化状态
    initial_state = {
        "messages": [
            LLMMessage(role="user", content="你好，请用一句话介绍 LangGraph")
        ]
    }
    
    # 运行图（使用 thread_id 来标识会话）
    result = graph.invoke(initial_state, config={"configurable": {"thread_id": "demo-1"}})
    
    print(f"\n用户: {initial_state['messages'][0].content}")
    print(f"助手: {result['messages'][-1].content}")


async def demo_rag_workflow():
    """演示 2：RAG 工作流"""
    print("\n" + "="*60)
    print("演示 2：RAG 工作流")
    print("="*60)
    
    graph = create_rag_graph()
    
    initial_state = {
        "messages": [],
        "user_input": "什么是投资组合？",
        "user_id": "demo_user",
        "rag_context": "",
        "documents": [],
        "final_answer": "",
    }
    
    result = graph.invoke(initial_state, config={"configurable": {"thread_id": "demo-2"}})
    
    print(f"\n用户问题: {result['user_input']}")
    print(f"\n检索到 {len(result['documents'])} 个文档")
    print(f"\n最终答案:\n{result['final_answer']}")


async def demo_agent_with_tools():
    """演示 3：带工具调用的 Agent"""
    print("\n" + "="*60)
    print("演示 3：带工具调用的 Agent（简化版）")
    print("="*60)
    
    graph = create_agent_graph()
    
    initial_state = {
        "messages": [
            LLMMessage(role="user", content="帮我查询当前时间")
        ],
        "user_input": "帮我查询当前时间",
        "user_id": "demo_user",
        "tool_calls": [],
        "tool_results": [],
        "iteration_count": 0,
    }
    
    result = graph.invoke(initial_state, config={"configurable": {"thread_id": "demo-3"}})
    
    print(f"\n用户: {result['user_input']}")
    print(f"\n最终回复: {result['messages'][-1].content}")
    print(f"\n工具调用次数: {result['iteration_count']}")


async def main():
    """运行所有演示"""
    print("\n🚀 LangGraph 入门演示")
    print("="*60)
    
    try:
        # 演示 1：简单聊天
        await demo_simple_chat()
        
        # 演示 2：RAG 工作流
        await demo_rag_workflow()
        
        # 演示 3：工具调用 Agent
        await demo_agent_with_tools()
        
    except Exception as e:
        logger.error(f"演示过程中出错: {e}", exc_info=True)
        print(f"\n❌ 错误: {e}")
        print("\n提示：请确保：")
        print("1. 已安装 langgraph: pip install langgraph")
        print("2. config.yaml 配置正确")
        print("3. 知识库已初始化（如果使用 RAG）")


if __name__ == "__main__":
    asyncio.run(main())

