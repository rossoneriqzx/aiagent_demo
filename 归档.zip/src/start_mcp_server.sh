#!/bin/bash

# 启动 Fake MCP Server 的脚本

echo "🚀 启动 Fake MCP Server..."
echo ""

# 检查是否在正确的目录
if [ ! -f "fake_mcp_server.py" ]; then
    echo "❌ 错误: 请在 src 目录下运行此脚本"
    exit 1
fi

# 启动 MCP 服务器
echo "✅ 启动 MCP 服务器..."
echo "📡 服务器地址: http://127.0.0.1:8000"
echo "📋 工具列表: GET http://127.0.0.1:8000/tools"
echo "🔧 调用工具: POST http://127.0.0.1:8000/call"
echo "按 Ctrl+C 停止服务器"
echo ""

python -m uvicorn fake_mcp_server:app --host 127.0.0.1 --port 8000


