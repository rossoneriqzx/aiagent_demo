"""
web.py - FastAPI Web 应用

提供 Web 界面和 REST API 来与 Agent 交互
"""

from __future__ import annotations

import asyncio
import json
import logging
from typing import Optional

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import HTMLResponse, StreamingResponse
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel

from agent import create_agent, sample_time_tool, sample_add_tool
from config import ConfigManager

logger = logging.getLogger(__name__)

# 配置日志
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(name)s: %(message)s",
)

# 创建 FastAPI 应用
app = FastAPI(
    title="智能投资顾问 Agent",
    description="基于 RAG 和工具调用的智能投资顾问系统",
    version="1.0.0",
)

# 配置 CORS（允许前端跨域访问）
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],  # 生产环境应该限制具体域名
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# 初始化 Agent（全局单例）
_agent = None
_config = None


def get_agent():
    """获取或创建 Agent 实例"""
    global _agent, _config
    if _agent is None:
        cfg_manager = ConfigManager()
        _config = cfg_manager.get_config()
        
        # 注册示例工具
        tools = {
            "get_time": sample_time_tool,
            "add_numbers": sample_add_tool,
        }
        
        _agent = create_agent(extra_tools=tools)
        logger.info("Agent 初始化完成")
    return _agent


# ========= 数据模型 =========

class ChatRequest(BaseModel):
    """聊天请求模型"""
    message: str
    user_id: Optional[str] = "web_user"
    enable_rag: bool = True
    enable_tools: bool = True


class ChatResponse(BaseModel):
    """聊天响应模型"""
    content: str
    model: str
    usage: Optional[dict] = None
    finish_reason: Optional[str] = None
    tool_calls: Optional[list] = None


class ConfigResponse(BaseModel):
    """配置信息响应模型"""
    model_config = {"protected_namespaces": ()}  # 解决 model_ 前缀警告
    model_provider: str
    model_name: str
    base_url: Optional[str]
    knowledge_base_enabled: bool
    mcp_enabled: bool


# ========= API 路由 =========

@app.get("/", response_class=HTMLResponse)
async def read_root():
    """返回前端 HTML 页面"""
    import os
    static_path = os.path.join(os.path.dirname(__file__), "static", "index.html")
    try:
        with open(static_path, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    except FileNotFoundError:
        return HTMLResponse(
            content="""
            <html>
                <head><title>智能投资顾问 Agent</title></head>
                <body>
                    <h1>智能投资顾问 Agent</h1>
                    <p>前端文件未找到，请确保 static/index.html 存在。</p>
                    <p>路径: {}</p>
                </body>
            </html>
            """.format(static_path),
            status_code=404
        )


@app.get("/api/health")
async def health_check():
    """健康检查端点"""
    return {"status": "ok", "service": "investment-agent"}


@app.get("/api/config", response_model=ConfigResponse)
async def get_config():
    """获取当前配置信息"""
    agent = get_agent()
    cfg = agent.cfg
    
    return ConfigResponse(
        model_provider=cfg.model.provider.value,
        model_name=cfg.model.model_name,
        base_url=cfg.model.base_url,
        knowledge_base_enabled=cfg.knowledge_base.enabled,
        mcp_enabled=cfg.use_mcp,
    )


@app.post("/api/chat", response_model=ChatResponse)
async def chat(request: ChatRequest):
    """
    非流式聊天接口
    """
    try:
        agent = get_agent()
        
        # 确保 user_id 不为 None，使用默认值 'web_user'
        actual_user_id = request.user_id or "web_user"
        
        # 打印调试日志
        logger.info(f"收到聊天请求: {request.message[:50]}... (RAG={request.enable_rag}, Tools={request.enable_tools})")
        logger.info(f"user_id: {actual_user_id}, Agent 实例 ID: {id(agent)}")
        logger.info(f"记忆功能状态: enabled={agent.cfg.memory_enabled}, window={agent.history_window}")
        
        # 检查历史记录状态
        if actual_user_id in agent.user_histories:
            history_count = len(agent.user_histories[actual_user_id])
            logger.info(f"📚 用户 {actual_user_id} 当前有 {history_count} 条历史记录（{history_count//2} 轮对话）")
            # 显示最近一轮对话的预览
            if history_count >= 2:
                last_user = agent.user_histories[actual_user_id][-2].content[:30]
                last_assistant = agent.user_histories[actual_user_id][-1].content[:30]
                logger.debug(f"最近对话预览: 用户: {last_user}... | 助手: {last_assistant}...")
        else:
            logger.info(f"📚 用户 {actual_user_id} 暂无历史记录（首次对话）")
        
        response = await agent.chat(
            user_input=request.message,
            user_id=actual_user_id,
            enable_rag=request.enable_rag,
            enable_tools=request.enable_tools,
        )
        
        # 打印结果摘要
        if response.tool_calls:
            logger.info(f"🔧 触发工具调用: {[t['function']['name'] for t in response.tool_calls]}")
        else:
            logger.info("📝 普通回复 (无工具调用)")
        
        # 再次检查历史记录状态（确认已保存）
        if actual_user_id in agent.user_histories:
            history_count = len(agent.user_histories[actual_user_id])
            logger.info(f"✅ 对话后，用户 {actual_user_id} 现在有 {history_count} 条历史记录（{history_count//2} 轮对话）")
            
        return ChatResponse(
            content=response.content,
            model=response.model,
            usage=response.usage,
            finish_reason=response.finish_reason,
            tool_calls=response.tool_calls if response.tool_calls else None,
        )
    except Exception as e:
        logger.error(f"聊天请求失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"处理请求时出错: {str(e)}")


@app.post("/api/chat/stream")
async def chat_stream(request: ChatRequest):
    """
    流式聊天接口（Server-Sent Events）
    """
    async def generate():
        try:
            agent = get_agent()
            
            # 发送初始消息
            yield f"data: {json.dumps({'type': 'start', 'message': '开始生成回复...'}, ensure_ascii=False)}\n\n"
            
            # 确保 user_id 不为 None，使用默认值 'web_user'
            actual_user_id = request.user_id or "web_user"
            logger.info(f"流式模式 - 实际使用的 user_id: {actual_user_id} (原始值: {request.user_id})")
            
            # 流式调用
            full_content = ""
            final_usage = None
            
            async for chunk in agent.stream_chat(
                user_input=request.message,
                user_id=actual_user_id,
                enable_rag=request.enable_rag,
                enable_tools=request.enable_tools,  # 恢复前端传入的开关
            ):
                if chunk.content:
                    full_content += chunk.content
                    yield f"data: {json.dumps({'type': 'chunk', 'content': chunk.content}, ensure_ascii=False)}\n\n"
                
                if chunk.is_final:
                    if chunk.usage:
                        final_usage = chunk.usage
                        yield f"data: {json.dumps({'type': 'usage', 'usage': chunk.usage}, ensure_ascii=False)}\n\n"
                    # 不 break，让 generator 正常结束，确保 agent 端的 finally 块执行
                    # 流式输出会在 yield final chunk 后自然结束
            
            # 发送完成消息
            yield f"data: {json.dumps({'type': 'done', 'content': full_content}, ensure_ascii=False)}\n\n"
            
            # 记录流式输出完成
            logger.info(f"✅ 流式输出完成（user_id={actual_user_id}，内容长度={len(full_content)}）")
            
        except Exception as e:
            logger.error(f"流式聊天失败: {e}", exc_info=True)
            error_msg = json.dumps({
                'type': 'error',
                'message': f'处理请求时出错: {str(e)}'
            }, ensure_ascii=False)
            yield f"data: {error_msg}\n\n"
    
    return StreamingResponse(
        generate(),
        media_type="text/event-stream",
        headers={
            "Cache-Control": "no-cache",
            "Connection": "keep-alive",
            "X-Accel-Buffering": "no",
        },
    )


@app.get("/api/history/{user_id}")
async def get_history(user_id: str, limit: int = 10):
    """
    获取用户聊天历史（从 Agent 的内存中读取）
    """
    try:
        agent = get_agent()
        
        # 获取历史记录
        history = []
        if user_id in agent.user_histories:
            history_list = agent.user_histories[user_id]
            # 限制返回数量
            history_list = history_list[-limit * 2:] if len(history_list) > limit * 2 else history_list
            
            for msg in history_list:
                history.append({
                    "role": msg.role,
                    "content": msg.content,
                })
        
        # 获取总结信息
        summary = agent.user_summaries.get(user_id, "")
        
        # 调试信息
        logger.info(f"📊 查询历史记录：user_id={user_id}, 历史记录数={len(agent.user_histories.get(user_id, []))}, 所有用户={list(agent.user_histories.keys())}")
        
        return {
            "user_id": user_id,
            "history_count": len(agent.user_histories.get(user_id, [])),
            "rounds": len(agent.user_histories.get(user_id, [])) // 2,
            "messages": history,
            "summary": summary,
            "memory_enabled": agent.cfg.memory_enabled,
            "agent_instance_id": id(agent),
            "all_user_ids": list(agent.user_histories.keys()),
        }
    except Exception as e:
        logger.error(f"获取历史记录失败: {e}", exc_info=True)
        raise HTTPException(status_code=500, detail=f"获取历史记录失败: {str(e)}")


# ========= 静态文件服务 =========

try:
    import os
    static_dir = os.path.join(os.path.dirname(__file__), "static")
    if os.path.exists(static_dir):
        app.mount("/static", StaticFiles(directory=static_dir), name="static")
        logger.info(f"静态文件目录已挂载: {static_dir}")
    else:
        logger.warning(f"静态文件目录不存在: {static_dir}")
except Exception as e:
    logger.warning(f"无法挂载静态文件目录: {e}")


# ========= 启动事件 =========

@app.on_event("startup")
async def startup_event():
    """应用启动时初始化"""
    logger.info("Web 应用启动中...")
    # 预加载 Agent
    get_agent()
    logger.info("Web 应用启动完成")


@app.on_event("shutdown")
async def shutdown_event():
    """应用关闭时清理"""
    logger.info("Web 应用关闭中...")


# ========= 主程序入口 =========

if __name__ == "__main__":
    import uvicorn
    
    # 直接运行 python web.py 时，使用 app 对象
    # 使用 uvicorn.run("web:app", ...) 时，需要从模块路径导入
    uvicorn.run(
        app,  # 直接传递 app 对象，这样可以直接运行 python web.py
        host="0.0.0.0",
        port=8080,
        reload=False,  # 直接运行时关闭 reload，避免路径问题
        log_level="info",
    )

