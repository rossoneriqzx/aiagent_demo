"""
fake_mcp_server.py - 简单的 MCP 服务器实现（用于测试）

这是一个简单的 MCP 服务器实现，提供基本的工具接口：
- GET /tools - 返回工具列表
- POST /call - 调用工具

使用方法：
    python -m uvicorn fake_mcp_server:app --host 127.0.0.1 --port 8000
"""

from fastapi import FastAPI
from pydantic import BaseModel
from typing import Any, Dict, List

app = FastAPI()

class CallRequest(BaseModel):
    tool: str
    arguments: Dict[str, Any]

class CallResponse(BaseModel):
    result: Any

# 示例工具列表
TOOLS = [
    {
        "name": "get_time",
        "description": "获取当前时间",
        "parameters": {
            "type": "object",
            "properties": {},
            "required": []
        }
    },
    {
        "name": "calculate",
        "description": "执行数学计算",
        "parameters": {
            "type": "object",
            "properties": {
                "expression": {
                    "type": "string",
                    "description": "要计算的数学表达式，例如 '2+2' 或 '10*5'"
                }
            },
            "required": ["expression"]
        }
    },
    {
        "name": "web_search",
        "description": "搜索网络信息",
        "parameters": {
            "type": "object",
            "properties": {
                "query": {
                    "type": "string",
                    "description": "搜索关键词"
                }
            },
            "required": ["query"]
        }
    }
]

@app.get("/")
async def root():
    """根路径，返回服务器信息"""
    return {
        "name": "Fake MCP Server",
        "version": "1.0.0",
        "tools_count": len(TOOLS)
    }

@app.get("/tools")
async def get_tools() -> List[Dict[str, Any]]:
    """
    返回可用的工具列表
    
    Returns:
        List[Dict]: 工具列表，每个工具包含 name, description, parameters
    """
    return TOOLS

@app.post("/call", response_model=CallResponse)
async def call_tool(request: CallRequest) -> CallResponse:
    """
    调用指定的工具
    
    Args:
        request: 工具调用请求，包含 tool 名称和 arguments
        
    Returns:
        CallResponse: 工具执行结果
    """
    tool_name = request.tool
    
    if tool_name == "get_time":
        from datetime import datetime
        result = {
            "current_time": datetime.now().isoformat(),
            "timestamp": datetime.now().timestamp()
        }
    elif tool_name == "calculate":
        expression = request.arguments.get("expression", "")
        try:
            # 安全的数学表达式计算（仅支持基本运算）
            result = eval(expression, {"__builtins__": {}}, {})
        except Exception as e:
            result = {"error": f"计算失败: {str(e)}"}
    elif tool_name == "web_search":
        query = request.arguments.get("query", "")
        # 模拟搜索结果
        result = {
            "query": query,
            "results": [
                f"关于 '{query}' 的搜索结果 1",
                f"关于 '{query}' 的搜索结果 2",
                f"关于 '{query}' 的搜索结果 3"
            ],
            "note": "这是模拟搜索结果，实际应用中需要连接真实的搜索引擎"
        }
    else:
        result = {"error": f"未知的工具: {tool_name}"}
    
    return CallResponse(result=result)

if __name__ == "__main__":
    import uvicorn
    print("🚀 启动 Fake MCP Server...")
    print("📡 服务器地址: http://127.0.0.1:8000")
    print("📋 工具列表: GET http://127.0.0.1:8000/tools")
    print("🔧 调用工具: POST http://127.0.0.1:8000/call")
    print("按 Ctrl+C 停止服务器")
    uvicorn.run(app, host="127.0.0.1", port=8000)


